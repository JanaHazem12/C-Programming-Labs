#include <stdio.h>
#include <stdlib.h>

int main()
{
    // receive numbers from a user, and e
    int sum = 0;
    // int i = 0;
    int number = 0;
    while (sum <= 100) {
        printf("Enter a number: ");
        scanf(" %d", &number);
        sum+=number;
        if (sum == 100)
            break;
    }
    if (sum >= 100){
        printf("sum exceeded 100!");
    }
    return 0;
}
