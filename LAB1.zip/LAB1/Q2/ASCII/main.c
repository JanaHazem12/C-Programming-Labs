#include <stdio.h>
#include <stdlib.h>

int main()
{
   char y;
   printf("Enter a character\n");
   scanf("%c", &y);
   printf("c=%d\n",y);
   return 0;
}
