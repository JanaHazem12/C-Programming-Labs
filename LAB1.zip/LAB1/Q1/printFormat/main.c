#include <stdio.h>
#include <stdlib.h>

int main()
{
   int a = 1;
   char b = 'j';
   float c = 2.2;
   printf("%d, %c, %0.2f\n",a,b,c); // 0.2 shows 2 numbers after the decimal point
   return 0;
}
