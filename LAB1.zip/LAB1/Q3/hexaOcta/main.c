#include <stdio.h>
#include <stdlib.h>

int main()
{
    int y=10;
    printf("c=%x\n", y); // hexadecimal
    printf("c=%o\n", y); // octal
    return 0;
}
