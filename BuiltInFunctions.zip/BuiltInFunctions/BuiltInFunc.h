int strLength_jana(char str[]); // DONEEEE
void strCopy_jana(char source[], char dest[]); // DONEEEE
void lowerToUpper_jana(char strLU[]); // DONEEEE
void upperTolower_jana(char strUL[]); // DONEEEE
void strConcat_jana(char dest[], char source[]); // DONEEEE
int strComp_jana(char dest[], char source[]);// DONEEEE
