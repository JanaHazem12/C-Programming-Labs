#include <stdio.h>
#include <stdlib.h>

// Write a recursive function to compute the power operation: X^Y
// example 2^3 = 2 x 2 x 2 = 8 - 2^4 = 2 x 2 x 2 x 2 = 16 --> Y is the repeated  number --> X * no. of Ys

int powerOperation(int x, int y){
    if(y == 0){
        return 1;
    }
    else{
        return x * powerOperation(x,y-1);
    }
    return 0;
}

int main(){
    int operation;
    int x;
    int y;
    printf("please enter a value for X: ");
    scanf(" %d", &x);
    printf("please enter a value for Y: ");
    scanf(" %d", &y);
    operation = powerOperation(x,y);
    printf("Power Operation= %d", operation);
    return 0;
}
