#ifdef _WIN32
#include <windows.h>    // for win32 API functions
#include <io.h>         // for _get_osfhandle()
#else
#ifndef _POSIX_SOURCE
#define _POSIX_SOURCE   // enable POSIX extensions in standard library headers
#endif
#include <unistd.h>     // for isatty()
#endif
#define SIZE 5
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <windows.h>




void gotoxy1(int x, int y){
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle (STD_OUTPUT_HANDLE), coord) ;
}

// use an enum for platform-independent interface:
typedef enum TextColor
{
    TC_BLACK = 0,
    TC_BLUE = 1,
    TC_GREEN = 2,
    TC_CYAN = 3,
    TC_RED = 4,
    TC_MAGENTA = 5,
    TC_BROWN = 6,
    TC_LIGHTGRAY = 7,
    TC_DARKGRAY = 8,
    TC_LIGHTBLUE = 9,
    TC_LIGHTGREEN = 10,
    TC_LIGHTCYAN = 11,
    TC_LIGHTRED = 12,
    TC_LIGHTMAGENTA = 13,
    TC_YELLOW = 14,
    TC_WHITE = 15
} TextColor;

// set output color on the given stream:
void setTextColor(FILE *stream, TextColor color);

int Arrows(char key, int pos){
    if(key==72){ //arrow up
        if(pos == 1){
            pos = 4;
        }
        else{
            pos-=1;
        }
    }
    else if(key==80){ //arrow down
        if(pos == 4){
            pos=1;
        }
        else{
            pos+=1;
        }
    }
    /*else if(key==75 || key==77){ // left & right keys
            pos=-1; // TESTING right/left keys
    }*/
    return pos;
}

typedef struct Employee{
    int id;
    char name[20];
    //int age;
    int salary;
}Employee;

Employee e1[SIZE];

int enter_Employee(Employee e[ ], int c); // PROTOTYPE
void display_Employee(Employee e[ ], int c); // PROTOTYPE
void modify_Employee(Employee e[ ], int c); // PROTOTYPE
int uniqueID(int userID); // PROTOTYPE

//Employee e1[SIZE];
//int userID;

int main(void)
{
    int c=0;
    int pos=1;
    int row=10;
    int column=5;
    setTextColor(stdout, TC_BLUE);
    gotoxy1(row,column);
    printf("New");
    setTextColor(stdout, TC_WHITE);
    gotoxy1(row,column+4);
    printf("Display");
    gotoxy1(row, column+8);
    printf("Exit");
    gotoxy1(row,column+12);
    printf("Modify");
    int flag=1;
    while(flag==1){
        char key=0;
        key = getch();

        if(key==-32){ // up, down, left, right
            key = getch();
            //printf("%d\n", key);
            pos = Arrows(key,pos);
            if(pos==1){
                system("cls"); //sys OR system ??
                setTextColor(stdout, TC_BLUE);
                gotoxy1(row,column);
                printf("New");
                setTextColor(stdout, TC_WHITE);
                gotoxy1(row,column+4);
                printf("Display");
                gotoxy1(row, column+8);
                printf("Exit");
                setTextColor(stdout, TC_WHITE);
                gotoxy1(row,column+12);
                printf("Modify");
            }
            if(pos==2){
                system("cls"); //sys OR system ??
                setTextColor(stdout, TC_WHITE);
                gotoxy1(row,column);
                printf("New");
                setTextColor(stdout, TC_BLUE);
                gotoxy1(row,column+4);
                printf("Display");
                gotoxy1(row, column+8);
                setTextColor(stdout, TC_WHITE);
                printf("Exit");
                setTextColor(stdout, TC_WHITE);
                gotoxy1(row,column+12);
                printf("Modify");
            }
            if(pos==3){
                system("cls"); //sys OR system ??
                setTextColor(stdout, TC_WHITE);
                gotoxy1(row,column);
                printf("New");
                setTextColor(stdout, TC_WHITE);
                gotoxy1(row,column+4);
                printf("Display");
                gotoxy1(row, column+8);
                setTextColor(stdout, TC_BLUE);
                printf("Exit");
                setTextColor(stdout, TC_WHITE);
                gotoxy1(row,column+12);
                printf("Modify");
            }
            if(pos==4){
                system("cls"); //sys OR system ??
                setTextColor(stdout, TC_WHITE);
                gotoxy1(row,column);
                printf("New");
                setTextColor(stdout, TC_WHITE);
                gotoxy1(row,column+4);
                printf("Display");
                gotoxy1(row, column+8);
                setTextColor(stdout, TC_WHITE);
                printf("Exit");
                setTextColor(stdout, TC_BLUE);
                gotoxy1(row,column+12);
                printf("Modify");
            }
            /*if(pos==-1){ // TESTING right/left keys
                key= getch(); // waiting for another key to be pressed
            }*/

        }

        else if(key==13){ // enter
            switch(pos){
                case 1:
                    system("cls");
                    setTextColor(stdout, TC_WHITE);
                    int f=1;
                    gotoxy1(row,column);
                    c=enter_Employee(e1, c);
                    break;


                case 2: system("cls");
                    setTextColor(stdout, TC_WHITE);
                    gotoxy1(row,column);
                    display_Employee(e1, c);
                    break;

                case 3: system("cls");
                    setTextColor(stdout, TC_WHITE);
                    gotoxy1(row,column);
                    printf("Exit");
                    return 0; // QUITTING
                    break;

                case 4: system("cls");
                    setTextColor(stdout, TC_WHITE);
                    gotoxy1(row,column);
                    //printf("Modify");
                    //uniqueID(e[c].id);
                    modify_Employee(e1,c);
                    break;

                    // display employees by their ID only DONEEE,
                    // choose employee id you want to modify DONEEE,
                    // asks you what do u want to modify ? for ex: name, salary, THEN modify it
            }

        }
        else if(key==27){ // ESCAPE key
            // printf("%d\n", key);
            system("cls"); //sys OR system ??
            setTextColor(stdout, TC_BLUE);
            gotoxy1(row,column);
            printf("New");
            setTextColor(stdout, TC_WHITE);
            gotoxy1(row,column+4);
            printf("Display");
            setTextColor(stdout, TC_WHITE);
            gotoxy1(row, column+8);
            printf("Exit");
            setTextColor(stdout, TC_WHITE);
            gotoxy1(row, column+12);
            printf("Modify");

        }
        /*else if(key==75||key==77){ // left, right

        }*/
    }
    return 0; //
}

int uniqueID(int userID){ // temp is IDs that are already saved, userID is the user input rn
    //int f=1;
    int i=0;
    for(i=0; i<SIZE; i++){
        if(e1[i].id == userID){ // one of the IDs in the array = userinputID
            //f=0;
            return 0; // break the loop
        }// ID IS NOT UNIQUE
    }
    return 1;
}


int enter_Employee(Employee e[ ], int c){
                //printf("%d: ", c);
                int userID;
                int flag=0;
                int ff=0;
                char term;
                if(c<=SIZE){
                    printf("Enter Employee id= ");
                    while(!flag){
                    scanf(" %d", &userID);
                    /*while(scanf("%d%c", &userID, &term) != 2 || term != '\n' && !ff){
                            printf("Invalid input!\n");
                            printf("Please enter a valid Employee id= ");
                            //printf(" \n");
                            fflush(stdin);
                    }*/ // --> INT+CHAR VALIDATION, NOT CONTINUING WHEN I INPUT ONLY 1 INT !!!!
                    if(uniqueID(userID) == 0){ // unique = 1, not unique = 0
                        printf("ID ALREADY TAKEN!! ");
                        printf("Please a valid id= ");
                        //return 0; // finishes this function
                        }
                    else{
                        flag=1;
                        }
                    }
                    //flag=1;
                    e[c].id=userID;
                    gotoxy1(10,9);
                    printf("Enter Employee Name= ");
                    scanf("%s", e[c].name); // DO NOT USE & because NAME is a set of values NOT a single value like the rest char name[20];
                    gotoxy1(10,11);
                    printf("Enter Employee Salary= ");
                    scanf("%d", &e[c].salary);
                    c+=1;
    }
    return c;
}

void display_Employee(Employee e[ ], int c){
                if(c<=SIZE){
                int i=0;
                int r = 10;
                int col = 5;
                int sum = 0;
                //int size = 5; // r=10 c=5
                for(i=0; i<c; i++){ // looping over C to display data of the specific number of employees added!!
                //gotoxy1(10,5);
                printf("Employee id= %d \n", e[i].id);
                //gotoxy1(r,sum+1);
                //sum+=col;
                printf("Employee Name= %s \n", e[i].name);
                //gotoxy1(r,sum+1);
                //sum+=1;
                printf("Employee Salary= %d \n", e[i].salary);
                printf("\n");
                }
            }
return 0;
}

void modify_Employee(Employee e[ ], int c){
                 //int c;
                 int userID;
                 int i=0;
                 int r = 10;
                 int col = 5;
                 int sum = 0;
                 int num = 0;
                 //char attr = '\0';
                 int attr=0;
                 //char mod='\0';
                 int mod = 0;
                 int size = 5;
                 int arr[5];
                 // r=10 c=5

                 for(i=0; i<c; i++){ // looping over C to display data of the specific number of employees added!!
                    printf("Employee id= %d \n", e[i].id);
                 }
                 printf("Which id do you want to modify? ");
                 scanf(" %d", &num);

                 int fg=1;
                 while(fg){
                     for(i=0; i<c; i++){
                        printf("num: %d, id: %d", num, e1[i].id);
                        if(num==e[i].id){ // IF I INSERTED A NEW ID, ERRORRR
                             printf("Which attribute do you want to modify? ");
                             scanf(" %d", &attr);
                             if(attr == 1){ // CHANGE ID - MOD is new value
                                printf("modification: ");
                                //printf("old value: %d ", e1[i].id);
                                scanf(" %d", &e1[i].id);
                                //printf("new value: %d ", e1[i].id);
                        }
                            else if(attr == 2){
                                printf("modification: ");
                                //printf("old value: %s ", e1[i].name);
                                scanf(" %s", e1[i].name);
                                //printf("new value: %s ", e1[i].name);
                            }
                            else if(attr == 3){
                               printf("modification: ");
                               //printf("old value: %d ", e1[i].salary);
                               scanf(" %d", &e1[i].salary);
                               //printf("new value: %d ", e1[i].salary);
                            }
                             fg=0;
                            }
                        }

                     if(fg==0){ // attr --> 1 id, 2 name, 3 salary

                        //printf("%c ", mod);
                        // changing attributes

                     }
                     else{
                     printf("UNAVAILABLE ID, please enter a valid ID: ");
                     scanf(" %d", &num);
                     }
}

                 int flag=0;
                 //if(c<=SIZE){
                    //int i=0;
                    //int size = 5; // r=10 c=5
                    /*while(!flag){
                        printf("Please enter a valid ID: ");
                        scanf(" %d", &userID);
                        if(uniqueID(userID) == 0){ // unique = 1, not unique = 0
                            printf("ID ALREADY TAKEN!!!! ");
                            }
                        else{
                            flag=1;
                            }
                    }
                    e[c].id=userID;
                    c+=1;

                    printf("Which attribute do you want to modify? ");
                    // if scanf is == name, go to e1[i].name and change it

                    char choice[50];
                     do
                        {
                            printf("Which attribute do you want to modify? ");
                            fflush(stdin);
                            if (scanf("%s", &choice) != 1) //scanf returns the number of args successfully received
                            {
                                printf("Please enter a choice: \n");
                            }
                            else{
                            printf("Please enter a valid choice: \n");
                            }

                        }while ((strcmp(choice, "name") != 0) && (strcmp(choice, "salary") !=0) );
                }

                 int f=0;
                 for(int j=0; j<c; j++){
                    arr[j] = e[j].id;
                    if(num == arr[j]){ // [1,2,3] 2
                        f=1;
                        // ASKS USER WHAT TO MODIFY ? name, age, bd, salary -->
                        // CAN WE MODIFY MORE THAN 1 THING ??
                        /*

                         char choice[50];
                         do
                            {
                                printf("Please enter a command:");
                                if (scanf("%s", &choice) != 1) //scanf returns the number of args successfully received
                                {
                                    printf("Please enter a command\n");
                                }

                                printf("Please enter a valid command!\n");

                            } while (strcmp(choice, "name") != 0 || != 0
                                     || strcmp(choice, "salary")); //repeat above until input = "good"
                        */ // ----> doesn't take user input until it's a specific word
                  //  }
                //}
                 /*if(!f){
                       printf("AVAILABLE ID!! \n");
                     }*/

        //}
        return 0;
}



#ifdef _WIN32

void setTextColor(FILE *stream, TextColor color)
{
    int outfd = fileno(stream);
    HANDLE out = (HANDLE)_get_osfhandle(outfd);
    DWORD outType = GetFileType(out);
    DWORD mode;
    if (outType == FILE_TYPE_CHAR && GetConsoleMode(out, &mode))
    {
        // we're directly outputting to a win32 console if the file type
        // is FILE_TYPE_CHAR and GetConsoleMode() returns success

        SetConsoleTextAttribute(out, color);
        // the enum constants are defined to the same values
        // SetConsoleTextAttribute() uses, so just pass on.
    }
}

#else

static const char *ansiColorSequences[] =
{
    "\x1B[0;30m",
    "\x1B[0;34m",
    "\x1B[0;32m",
    "\x1B[0;36m",
    "\x1B[0;31m",
    "\x1B[0;35m",
    "\x1B[0;33m",
    "\x1B[0;37m",
    "\x1B[1;30m",
    "\x1B[1;34m",
    "\x1B[1;32m",
    "\x1B[1;36m",
    "\x1B[1;31m",
    "\x1B[1;35m",
    "\x1B[1;33m",
    "\x1B[1;37m"
};

static const char *ansiColorTerms[] =
{
    "xterm",
    "rxvt",
    "vt100",
    "linux",
    "screen",
    0
    // there are probably missing a few others
};

// get current terminal and check whether it's in our list of terminals
// supporting ANSI colors:
static int isAnsiColorTerm(void)
{
    char *term = getenv("TERM");
    for (const char **ansiTerm = &ansiColorTerms[0]; *ansiTerm; ++ansiTerm)
    {
        int match = 1;
        const char *t = term;
        const char *a = *ansiTerm;
        while (*a && *t)
        {
            if (*a++ != *t++)
            {
                match = 0;
                break;
            }
        }
        if (match) return 1;
    }
    return 0;
}

void setTextColor(FILE *stream, TextColor color)
{
    int outfd = fileno(stream);
    if (isatty(outfd) && isAnsiColorTerm())
    {
        // we're directly outputting to a terminal supporting ANSI colors,
        // so send the appropriate sequence:
        fputs(ansiColorSequences[color], stream);
    }
}

#endif
