int strLength_jana(char str[]);
char strCopy_jana(char source[], char dest[]);
